import React from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import '../index.css';

const ProductDetail = ({info}) => {
    const {id} =useParams();
    const index = id -1;
    const {category, description, image, price, title, rating} = info[index];
    const navigate = useNavigate();
    // console.log(info[index]);
  return (
    <div >
      <div >
        <button
        onClick={() => {navigate('/')}}
        > back</button>
        <h1 className='heading'>PRODUCT DETAIL</h1>
      </div>
    <div className='pdt-dtl-cnt'>
      <div className='pdt-dtl-img'>
        <img src={image} alt='img' />
      </div>
      <div className='pdt-dtl-txt'>
        <h1>{title}</h1>
        <h2>Price : ${price}</h2>
        <h2>description:</h2>
        <p>   {description}</p>
        <h3>Rating:</h3> <span>{rating.rate} ({rating.count})</span>
      </div>

    </div>
    </div>
  )
}

export default ProductDetail