import React from 'react'
import '../index.css'

const Filter = ({setRawData, rawData, filter, setFilter, setPage, setData}) => {

        const handleChangeFilter = event => {
            setFilter(event.target.value);
            // console.log(filter);
        }

        let cat = rawData.map((item) => item.category);
        const categories = cat.filter((value, index, self) => self.indexOf(value) === index);

        // setPage(0);
        
  return (
    <div className='filter'>
        <label htmlFor='filter'>Filter Categories</label>
        <select id='filter' value={filter} onChange = {handleChangeFilter}>
        <option value='' >all</option>
         {categories.map((data) => <option key={data} value={data} >{data}</option>)}   
        </select>
    </div>
  )
}

export default Filter