import React from 'react'

const FetchData = async(setRawData) => {
    const res = await fetch('https://fakestoreapi.com/products');
    const data = await res.json();
    const array = Object.values(data);
    setRawData(array)
}

export default FetchData