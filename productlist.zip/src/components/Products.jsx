import React from 'react';
import FetchData from './FetchData';
import { useNavigate } from 'react-router-dom';

const Products = ({setPage, setRawData ,page, data, setData, rawData, search, filter}) => {
  // console.log(rawData);
  // console.log(search);
  // console.log(filter);
  console.log(rawData);
  let newArray =[];
  let display = [];

  const navigate = useNavigate();

  // !rawData.lenth && <FetchData setRawData={setRawData}/> 
  if(filter === ''){
    rawData.map((product) => {
      if(product.title.toLowerCase().search(search.toLowerCase()) !== -1){
        newArray.push(product)
      }
    })
  } else {
    rawData.map((product) => {
      if(filter === product.category){
        if(product.title.toLowerCase().search(search.toLowerCase()) !== -1){
          newArray.push(product)
        }
      }
    })
    
  }

  // for(let i=page ;i < page + 4 ; i++ ){
  //   if(i<20){
  //     display.push(newArray[i])
  //   }
  // }console.log(display);

  return(
    <div>

    <div className='prd-container'>
      {newArray?.map((item) => (
      <div>
        <img className='prd-image' src={item.image} onClick={() => navigate(`/product/${item.id}`)} />
        <div className='txt-cnt'>
        <h2>{item.title}</h2>
        </div>
      </div>
      ))}
    
    </div >
    <br></br>
    <br></br>
    <br></br>
      <button onClick={() => {setPage((prev)=> prev -4 )}}>PREVIOUS</button>
      <button onClick={() => {setPage((prev)=> prev +4 )}}>NEXT</button>
    </div>
  )

}

export default Products