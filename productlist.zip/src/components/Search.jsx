import React from 'react'
import '../index.css'

const Search = ({ search, setSearch, setPage }) => {

  const handleChangeSearch = event => {
    setSearch(event.target.value);
    // console.log(search);
  }
  // setPage(0)
  return (
    <div className='search'>
      <input type='text' value={search} onChange={handleChangeSearch}/>
    </div>
  )
}

export default Search