import React from 'react'
import { useState, useEffect } from 'react'
import FetchData from './components/FetchData';

import Filter from './components/Filter'
import Products from './components/Products';
import Search from './components/Search';

const App = ({rawData, setRawData}) => {


    
    const [filter, setFilter] = useState('');
    const [search, setSearch] = useState('');
    const [page, setPage] = useState(0)
    const [data, setData] = useState([])
    if(!rawData.length) FetchData(setRawData) 

  return (
    <div>
        {rawData.length ? 
        <div>
            <h1>Products</h1>
        <Filter filter={filter} setPage={setPage} setFilter={setFilter} setData={setData} rawData={rawData} setRawData = {setRawData}/>
        <Search search={search} setPage={setPage} setSearch={setSearch}/>
        <Products setPage={setPage} setRawData={setRawData} setData={setData} page={page} data={data} search={search} filter={filter} rawData={rawData}/>
        </div> : 
        <div>
          {/* {FetchData(setRawData)   } */}
        </div>}
        
    </div>
  )
}

export default App