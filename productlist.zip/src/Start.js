import React, {useState, useEffect} from 'react'
import App from './App.jsx';
import { Routes, Route, useNavigate } from 'react-router-dom';
import FetchData from './components/FetchData.js';
import ProductDetail from './components/ProductDetail'


const Start = () => {

  const [rawData, setRawData] = useState([])

  useEffect(() => {
    FetchData(setRawData)
  }, [])

  return (
      <Routes >
        <Route path='/*' element={<App rawData = {rawData} setRawData={setRawData}/>}/>
        <Route path = '/product/:id' element={<ProductDetail info ={rawData}/>} />
      </Routes>
  )
}

export default Start