/* eslint-disable */
import React, { useEffect, useState } from 'react'
// import callApi from 'utils/callApi';
// import resizeImage from 'utils/resizeImage';
// import { notification } from 'antd'
// import './index.css';

const loadScript = (src) => {
  return new Promise((resolve) => {
    const script = document.createElement('script')
    script.src = src
    script.onload = () => {
      resolve(true)
    }

    script.onerror = () => {
      resolve(false)
    }
    document.body.appendChild(script)
  })
}

export default function Editor(props) {
  window.tinymce.dom.Event.domLoaded = true
  const { editorHtml, placeholder, onChange, name } = props
  const [textarea, settextarea] = useState(false)
  useEffect(() => {
    setTimeout(() => {
      window.tinymce.dom.Event.domLoaded = true
      settextarea(true)

      window.tinymce.init({
        selector: `.${name}`,
        plugins:
          'print preview paste importcss searchreplace autolink autosave save directionality code visualblocks visualchars fullscreen image link media template codesample table charmap hr pagebreak nonbreaking anchor toc insertdatetime advlist lists wordcount imagetools textpattern noneditable help charmap quickbars emoticons',
        imagetools_cors_hosts: ['picsum.photos'],
        menubar: 'file edit view insert format tools table help',
        toolbar:
          'undo redo | bold italic underline strikethrough | fontselect fontsizeselect formatselect | alignleft aligncenter alignright alignjustify | outdent indent |  numlist bullist | forecolor backcolor removeformat | pagebreak | charmap emoticons | fullscreen  preview save print | insertfile image media template link anchor codesample | ltr rtl',
        toolbar_sticky: true,
        autosave_ask_before_unload: true,
        autosave_interval: '30s',
        autosave_prefix: '{path}{query}-{id}-',
        autosave_restore_when_empty: false,
        autosave_retention: '2m',
        image_advtab: true,
        extended_valid_elements: 'img[class|src|alt|title|width|loading=lazy]',
        link_list: [
          { title: 'My page 1', value: 'https://www.tiny.cloud' },
          { title: 'My page 2', value: 'http://www.moxiecode.com' },
        ],
        image_list: [
          { title: 'My page 1', value: 'https://www.tiny.cloud' },
          { title: 'My page 2', value: 'http://www.moxiecode.com' },
        ],
        image_class_list: [
          { title: 'None', value: '' },
          { title: 'Some class', value: 'class-name' },
        ],
        importcss_append: true,
        file_picker_callback: function (callback, value, meta) {
          /* Provide file and text for the link dialog */
          if (meta.filetype === 'file') {
            callback('https://www.google.com/logos/google.jpg', {
              text: 'My text',
            })
          }

          /* Provide image and alt text for the image dialog */
          if (meta.filetype === 'image') {
            callback('https://www.google.com/logos/google.jpg', {
              alt: 'My alt text',
            })
          }

          /* Provide alternative source and posted for the media dialog */
          if (meta.filetype === 'media') {
            callback('movie.mp4', {
              source2: 'alt.ogg',
              poster: 'https://www.google.com/logos/google.jpg',
            })
          }
        },
        templates: [
          {
            title: 'New Table',
            description: 'creates a new table',
            content:
              '<div class="mceTmpl"><table width="98%%"  border="0" cellspacing="0" cellpadding="0"><tr><th scope="col"> </th><th scope="col"> </th></tr><tr><td> </td><td> </td></tr></table></div>',
          },
          {
            title: 'Starting my story',
            description: 'A cure for writers block',
            content: 'Once upon a time...',
          },
          {
            title: 'New list with dates',
            description: 'New List with dates',
            content:
              '<div class="mceTmpl"><span class="cdate">cdate</span><br /><span class="mdate">mdate</span><h2>My List</h2><ul><li></li><li></li></ul></div>',
          },
        ],
        template_cdate_format: '[Date Created (CDATE): %m/%d/%Y : %H:%M:%S]',
        template_mdate_format: '[Date Modified (MDATE): %m/%d/%Y : %H:%M:%S]',
        height: 350,
        image_caption: true,
        quickbars_selection_toolbar:
          'bold italic | quicklink h2 h3 blockquote quickimage quicktable',
        noneditable_noneditable_class: 'mceNonEditable',
        toolbar_mode: 'sliding',
        contextmenu: 'link image imagetools table',
        content_style:
          'body { font-family:Helvetica,Arial,sans-serif; font-size:14px }',

        // -----------------Old version-------------------------------

        // selector: '.kt-tinymce-4',
        // height: 400,
        // theme: 'modern',
        // menubar: 'file view insert format tools table tc help',
        // toolbar: [
        //   'styleselect fontselect fontsizeselect',
        //   'undo redo | cut copy | forecolor backcolor | bold italic | link image | alignleft aligncenter alignright alignjustify',
        //   'bullist numlist | outdent indent | blockquote subscript superscript | advlist | autolink | lists charmap | print preview |  code',
        // ],
        // plugins: 'paste advlist textcolor colorpicker autolink link image lists charmap print preview code',
        // automatic_uploads: true,
        // file_picker_types: 'image',
        // image_title: true,
        //     // init_instance_callback: function (ed) {
        //     //   ed.execCommand('mceImage');
        //     // },

        // -----------------Old version-------------------------------

        // file_picker_callback: function (cb, value, meta) {
        //   var input = document.createElement('input');
        //   input.setAttribute('type', 'file');
        //   input.setAttribute('accept', 'image/*');
        //   input.onchange = async function () {
        //     var file = this.files[0];
        //     console.log('File insert', file);
        //     const url = '/api/uploadimage';
        //     const formData = new FormData();

        //     const getNewImage = await resizeImage(file, 300, 300);
        //     console.log('GETNEw Iamge', getNewImage, getNewImage.size);

        //     formData.append('image', file);
        //     const options = {
        //       method: 'POST',
        //       body: formData,
        //     };
        //     let Imageurl = null;
        //     try {
        //       const responseJSON = await callApi(url, options);
        //       console.log('responseKson', responseJSON);
        //       if (responseJSON && responseJSON.success) {
        //         Imageurl = responseJSON.url;
        //         cb(responseJSON.url, { title: file.name });
        //       }
        //     } catch (err) {
        //       console.log('error', err);
        //       notification.error({
        //         message: 'Error!',
        //         // description: err.message,
        //       });
        //     }
        //   };

        //   input.click();
        // },
      })

      window?.tinymce?.activeEditor?.on('change', () => {
        onChange(window.tinymce.activeEditor.getContent())
        console.log('the-content', window.tinymce.activeEditor.getContent())
      })
    }, 2000)

    return () => window?.tinymce?.remove(`.${name}`)
  }, [])

  return (
    <div>
      <div>
        {textarea ? (
          <textarea
            hidden
            placeholder={placeholder}
            className={name}
            onChange={onChange}
            name={name}
          >
            {editorHtml}
          </textarea>
        ) : (
          <div>Loading.....</div>
        )}
      </div>
    </div>
  )
}

Editor.defaultProps = {
  placeholder: 'Write something...',
}
